console.log("INSTALLER START");

var Service = require('node-windows').Service;

console.log("MODULE LOADED");

var svc = new Service({
  name: 'PathoService',
  description: 'Patho search service',
  script: '***\\nodejs\\scripts\\pathoserver.js'
});

console.log("SERVICE CREATED");

svc.on('install', function() {

  console.log('INSTALLED');

  svc.start();

});

svc.on('start', function() {

  console.log('STARTED');

});

svc.on('alreadyinstalled', function() {

  console.log('ALREADY INSTALLED');

});

svc.on('invalidinstallation', function() {

  console.log('INVALID INSTALL');

});

svc.on('error', function(err) {

  console.log('ERROR');
  console.log(err);

});

console.log("CALL INSTALL");

svc.install();

console.log("END FILE");