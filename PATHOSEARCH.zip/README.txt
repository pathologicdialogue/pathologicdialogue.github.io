CONTAINS EVERYTHING NEEDED FOR THE PATHOLOGIC DIALOGUE SEARCH

To get started: go through all the files, seach for "***" and replace them with your configuration
The project was created using NodeJS v6.10.1, MySQL database v5.7 and Apache24 as an application server, so some changes may be required if higher versions are used

Containing files:

FRONTEND
index.html: the main seach home page
style.css: styles for the main page
help.html: help page for the search, explaining the use of the wildcards and tips for efficient usage
app.js: all the scripts for the main page
admin.html: admin panel that shows the logs and has control buttons to reindex all the repo pages and rebuild all the text indexes from scratch
admin.js: all the scripts for the admin page

BACKEND:
indexer.js: a script to fill the database with the indexed dialogues and construct text indexes. Callable from the admin page.

SERVER FILES:
pathoserver.js: node server, contain all the redirects and sql queries to the database
service.js: a helper script to put the node server as a windows service

DATABASE CONFIGURATION
schema.sql: schema config restoration file
The schema "pathologicsearch" contains the tables:

dialogue_blocks: stores all the parsed dialogues
	CREATE TABLE `dialogue_blocks` (
 		`id` int(11) NOT NULL AUTO_INCREMENT,
  		`page` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
		`title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
		`speaker` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
		`anchor_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
		`text_content` text COLLATE utf8mb4_unicode_ci NOT NULL,
  		`url` text COLLATE utf8mb4_unicode_ci,
  		`updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  		`block_hash` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
		`page_order` int(11) NOT NULL DEFAULT '0',
  		`language` varchar(16) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'unknown',
  		`game` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  		`text_normalized` longtext COLLATE utf8mb4_unicode_ci,
  		`last_seen_run` varchar(64) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  		`text_normalized_nopunct` text COLLATE utf8mb4_unicode_ci,
  		`text_nopunct` text COLLATE utf8mb4_unicode_ci,
  		PRIMARY KEY (`id`),
  		UNIQUE KEY `block_hash` (`block_hash`),
  		FULLTEXT KEY `ft_text` (`text_content`,`speaker`,`title`)
	) ENGINE=InnoDB AUTO_INCREMENT=362995 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci

search_index: stores the revirsed full text index
	CREATE TABLE `search_index` (
		`token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
		`dialogue_id` int(11) NOT NULL,
		PRIMARY KEY (`token`,`dialogue_id`),
		KEY `idx_dialogue` (`dialogue_id`)
	) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci

search_logs: stores all the logs for the seaches (mainly for the POPULAR SEARCHES section)
	CREATE TABLE `search_logs` (
  		`id` int(11) NOT NULL AUTO_INCREMENT,
  		`created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  		`query_text` text,
  		`normalized_query` text,
  		`languages` varchar(255) DEFAULT NULL,
  		`games` varchar(255) DEFAULT NULL,
  		`whole_word` tinyint(1) DEFAULT '0',
  		`result_count` int(11) DEFAULT '0',
  		`duration_ms` int(11) DEFAULT NULL,
  		`normalize_search` tinyint(1) NOT NULL DEFAULT '1',
  		`ignore_punctuation` tinyint(1) DEFAULT '1',
  		PRIMARY KEY (`id`)
	) ENGINE=InnoDB AUTO_INCREMENT=1472 DEFAULT CHARSET=utf8mb4

server_logs: stores all the server logs
	CREATE TABLE `server_logs` (
		`id` int(11) NOT NULL AUTO_INCREMENT,
		`created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
		`level` varchar(20) DEFAULT 'info',
		`message` text,
		PRIMARY KEY (`id`)
	) ENGINE=InnoDB AUTO_INCREMENT=9722 DEFAULT CHARSET=utf8mb4

