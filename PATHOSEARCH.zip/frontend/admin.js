const button = document.getElementById("update");
const status = document.getElementById("status");
const rebuild = document.getElementById("rebuild");
const log = document.getElementById("log");
var offset = 0;
var loading = false;
var finished = false;
var newestId = 0;


// ---------- EVENTS ----------

button.addEventListener("click", reindex);
rebuild.addEventListener("click", rebuildIndex);

console.log("button", button);
console.log("rebuild", rebuild);

log.addEventListener("scroll", function() {
    if (log.scrollTop + log.clientHeight >= log.scrollHeight - 300) {
      refreshLog();
    }
  }
);


// ---------- LOGS ----------

async function refreshLog() {
  if (loading || finished) {
    return;
  }

  loading = true;
  try {
    const res = await fetch("/pathosearch/api/log" + "?offset=" + offset + "&limit=50");
    const data = await res.json();
    if (!data.length) {
      finished = true;
      loading = false;
      return;
    }

    renderLogs(data);

    offset += data.length;
  }

  catch(err) {
    console.log(err);
  }

  loading = false;
}

async function refreshNewestLogs() {
  if (!newestId) {
    return;
  }

  try {
    const res =
      await fetch(
        "/pathosearch/api/lognew"
        +
        "?after="
        +
        newestId
      );

    const data = await res.json();

    if (!data.length) {
      return;
    }

    data.reverse();

    data.forEach(function(row) {
        newestId = Math.max(newestId, row.id);

        var line =
          "[" +
          row.created_at +
          "] "
          +
          row.level
          +
          " "
          +
          row.message;

        log.textContent =
          line
          +
          "\n"
          +
          log.textContent;
      }
    );
  }

  catch(err) {
    console.log(err);
  }
}

function renderLogs(data) {
  data.forEach(
    function(row) {
      if (row.id > newestId) {
        newestId = row.id;
      }

      var line =
        "[" +
        row.created_at +
        "] "
        +
        row.level
        +
        " "
        +
        row.message;

      log.textContent += line + "\n";
    }
  );
}

// ---------- REINDEX ----------

async function reindex() {
  status.innerText = "Indexing...";
  const res = await fetch("/pathosearch/api/reindex");
  const data = await res.json();
  if (data.ok) {
    status.innerText = "Done";
  }
  else {
    status.innerText = "Error";
  }
}

function rebuildIndex() {

  status.innerText =
    "Rebuilding index...";

  fetch(
    "/pathosearch/api/rebuildindex"
  )

  .then(function(r) {
    return r.json();
  })

  .then(function(data) {

    if (data.ok) {
      status.innerText =
        "Done";
    }
    else {
      status.innerText =
        "Error";
    }

    console.log(data);

  })

  .catch(function(err) {

    status.innerText =
      "Error";

    console.error(err);

  });
}


// ---------- INIT ----------

refreshLog();

setInterval(
  refreshNewestLogs,
  10000
);