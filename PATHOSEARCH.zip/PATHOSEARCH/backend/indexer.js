﻿module.paths.push("***/nodejs/node_modules");

var request = require("request");
var cheerio = require("cheerio");
var mysql = require("mysql");
var sha256 = require("sha256");
var addLog = console.log;
var he = require("he");

var BASE = "https://pathologicdialogue.github.io/";

var queue = [];
var processing = false;

var pool = mysql.createPool({
  connectionLimit: ***,
  host: ***,
  user: ***,
  password: ***,
  database: 'pathologic_search',
  charset: 'utf8mb4'
});

var visited = {};
var currentRunId = null;

function detectLanguage(url) {

  // ENGLISH
  if (
    url.indexOf("https://pathologicdialogue.github.io/html3_en/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html2_en/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_en/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_eo/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_demo/") === 0 ||
    url === "https://pathologicdialogue.github.io/pre_en.html"
  ) {
    return "en";
  }

  // RUSSIAN
  if (
    url.indexOf("https://pathologicdialogue.github.io/html3_ru/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html2_ru/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_ru/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_ro/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_alpha/") === 0 ||
    url ==="https://pathologicdialogue.github.io/pre_ru.html"
  ) {
    return "ru";
  }

  // PORTUGUESE
  if (
    url.indexOf("https://pathologicdialogue.github.io/html2_br/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_br/") === 0
  ) {
    return "pt";
  }

  // KOREAN
  if (
    url.indexOf("https://pathologicdialogue.github.io/html2_kr/") === 0
  ) {
    return "ko";
  }

  // CZECH
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_cz/") === 0
  ) {
    return "cs";
  }

  // GERMAN
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_de/") === 0
  ) {
    return "de";
  }

  // ITALIAN

  if (
    url.indexOf("https://pathologicdialogue.github.io/html_it/") === 0
  ) {
    return "it";
  }

  // POLISH
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_pl/") === 0
  ) {
    return "pl";
  }

  return "unknown";
}

function detectGame(url) {

  // PATHOLOGIC 3
  if (
    url.indexOf("https://pathologicdialogue.github.io/html3") === 0
  ) {
    return "p3";
  }

  // PATHOLOGIC 2
  if (
    url.indexOf("https://pathologicdialogue.github.io/html2") === 0
  ) {
    return "p2";
  }
 
  // DEMO
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_demo") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_alpha") === 0
  ) {
    return "demo";
  }

  // PRE
  if (
    url === "https://pathologicdialogue.github.io/pre_ru.html" ||
    url === "https://pathologicdialogue.github.io/pre_en.html"
  ) {
    return "pre";
  }

  // CLASSIC HD
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_en/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_ru/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_br/") === 0
  ) {
    return "HD";
  }

  // UTOPIA
  if (
    url.indexOf("https://pathologicdialogue.github.io/html_eo/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_ro/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_cz/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_de/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_it/") === 0 ||
    url.indexOf("https://pathologicdialogue.github.io/html_pl/") === 0
  ) {
    return "utopia";
  }

  return "unknown";
}

function fetchPage(url, callback) {
  addLog("FETCH: " + url);

  request({
    url: url,
    strictSSL: false
  }, function(err, response, body) {
    if (err || !body) {
      addLog("ERROR", err);
      callback();
      return;
    }

    parsePage(url, body, callback);
  });
}

function parsePage(url, html, callback) {
  var title = "";

  var titleMatch =
    html.match(/<title>(.*?)<\/title>/i);

  if (titleMatch) {
    title = he.decode(
      titleMatch[1]
        .trim()
        .normalize("NFC")
    );
  }

  var hash = sha256(html);
  addLog("REINDEX " + url);

  // ====================================
  // PARSER 1
  // ====================================
  addLog("TRY PARSER 1");

  extractArrayBlocks(
    html,
    title,
    url,
    hash,
    function(inserted, duplicates) {
      if (
        inserted > 0 ||
        duplicates > 0
      ) {
        crawlLinksRaw(html);
        callback();
        return;
      }

      // ====================================
      // PARSER 2
      // ====================================
      addLog("TRY PARSER 2");

      extractScriptBlocks(
        html,
        title,
        url,
        hash,
        function(foundScript) {
          addLog(
            "PARSER 2 BLOCKS " +
            foundScript
          );

          if (foundScript > 0) {
            crawlLinksRaw(html);
            callback();
            return;
          }

          // ====================================
          // PARSER 3
          // ====================================
          addLog("TRY PARSER 3");

          indexBlocks(
            html,
            title,
            url,
            hash,
            function(inserted, duplicates) {
              addLog(
                "PARSER 3: " +
                inserted +
                " inserted, " +
                duplicates +
                " duplicates"
              );
              crawlLinksRaw(html);
              callback();
            }
          );
        }
      );
    }
  );
}

function extractScriptBlocks(html, title, url, hash, done) {
  var found = 0;
  var order = 0;
  var language = detectLanguage(url);
  var game = detectGame(url);
  var regex = /["']((?:\\.|[^"'\\])*)["']/g;

  function next() {
    var match =
      regex.exec(html);
    if (!match) {
      done(found);
      return;
    }

    var text = he.decode(
      match[1]
        .replace(/\\"/g,'"')
        .replace(/\\'/g,"'")
        .replace(/\\n/g," ")
        .replace(/\s+/g," ")
        .trim()
        .normalize("NFC")
    );

    if (
      !hasLetters(text) ||
      /^[_a-zA-Z0-9-]+$/.test(text) ||
      (
        /[=,]/.test(text) &&
        text.indexOf(":") === -1
      ) ||
      text.indexOf("function(")!==-1 ||
      text.indexOf("jquery")!==-1 ||
      text.indexOf("data-role")!==-1 ||
      text.indexOf("viewport")!==-1 ||
      text.indexOf("stylesheet")!==-1 ||
      text.indexOf("href=")!==-1 ||
      text.indexOf("<div")!==-1 ||
      text.indexOf("<a")!==-1 ||
      text.indexOf("{")!==-1 ||
      text.indexOf("}")!==-1 ||
      (
        text.length < 15 &&
        text.indexOf(":")===-1 &&
        text.indexOf(" ")===-1
      )
    ) {
      setImmediate(next);
      return;
    }

    var speaker = "";
    var split =
      text.match(
        /^([^:]{1,80}):\s*(.+)$/
      );

    if (split) {
      speaker =
        split[1].trim();
      text =
        split[2].trim();
    }

    found++;
    order++;

    saveBlock({
      page: hash,
      title: title,
      speaker: speaker,
      text: text,
      url: url,
      pageOrder: order,
      language: language,
      game: game
    },
    function() {
      setImmediate(next);
    });
  }

  setImmediate(next);
}

function extractArrayBlocks(html, title, url, hash, done) {
  var match =
    html.match(
      /textarr\s*=\s*(\[[\s\S]*?\]);/
    );

  if (!match) {
    addLog("NO TEXTARR");
    done(0,0);
    return;
  }

  var arr;

  try {
    arr = eval(match[1]);
  }
  catch(e) {
    addLog(
      "TEXTARR PARSE ERROR: " + e
    );
    done(0,0);
    return;
  }

  var language = detectLanguage(url);
  var game = detectGame(url);

  addLog(
    "TEXTARR SIZE: " +
    arr.length
  );

  var inserted = 0;
  var duplicates = 0;
  var i = 0;

  function next() {
    if (i >= arr.length) {
      addLog(
        "PARSER 1 DONE: " +
        inserted +
        " inserted / " +
        duplicates +
        " duplicates"
      );
      done(
        inserted,
        duplicates
      );
      return;
    }

    var order =
      i + 1;
    var raw =
      String(
        arr[i++] || ""
      );
    var text =
      he.decode(
        raw
          .replace(/\s+/g," ")
          .trim()
          .normalize("NFC")
      );
    if (
      !text ||
      /^\d+\.?$/.test(text) ||
      !hasLetters(text)
    ) {
      setImmediate(next);
      return;
    }

    var speaker = "";
    var split =
      text.match(
        /^([^:]{1,80}):\s*(.+)$/
      );

    if (split) {
      speaker =
        split[1].trim();
      text =
        split[2].trim();
    }

    saveBlock({
      page: hash,
      title: title,
      speaker: speaker,
      text: text,
      url: url,
      pageOrder: order,
      language: language,
      game: game
    },

    function(result) {
      if (result==="duplicate") {
        duplicates++;
      }
      else if (result==="inserted") {
        inserted++;
      }
      setImmediate(next);
    });
  }
  next();
}

function indexBlocks(html, title, url, hash, done) {
  var regex = /<p[^>]*>([\s\S]*?)<\/p>/gi;
  var inserted = 0;
  var duplicates = 0;
  var order = 0;
  var language = detectLanguage(url);
  var game = detectGame(url);

  function stripTags(text) {
    return he.decode(
      text
        .replace(/<[^>]+>/g," ")
        .replace(/\s+/g," ")
        .trim()
        .normalize("NFC")
    );
  }

  function next() {
    var match =
      regex.exec(html);
    if (!match) {
      done(inserted, duplicates);
      return;
    }
    var raw = match[1];
    var text = stripTags(raw);

    if (
      !text ||
      !hasLetters(text)
    ) {
      setImmediate(next);
      return;
    }

    var speaker = "";
    var strongMatch = raw.match(/<strong[^>]*>(.*?)<\/strong>/i);

    if (strongMatch) {
      speaker =
        stripTags(
          strongMatch[1]
        );
    }

    order++;
    saveBlock({
      page: hash,
      title: title,
      speaker: speaker,
      text: text,
      url: url,
      pageOrder: order,
      language: language,
      game: game
    },

    function(result) {
      if (result==="duplicate") {
        duplicates++;
      }
      else {
        inserted++;
      }

      setImmediate(next);
    });
  }
  next();
}


function processQueue(done) {
  addLog(
    "QUEUE: " +
    queue.length +
    " PROCESSING: " +
    processing
  );

  if (processing) {
    return;
  }

  var next = queue.shift();

  if (!next) {
    addLog(
      "QUEUE DONE"
    );

    if (done) {
      done();
    }
    return;
  }

  processing = true;
  fetchPage(
    next,
    function() {
      processing = false;
      setTimeout(
        function() {
          processQueue(done);
        },
        300
      );
    }
  );
}

function saveBlock(data, callback) {
  var blockHash =
    sha256(
      data.speaker +
      "|" +
      data.text +
      "|" +
      data.url
    );

  pool.query(
    `
    SELECT
      id
    FROM dialogue_blocks
    WHERE
      block_hash = ?
    LIMIT 1
    `,
    [blockHash],
    function(err, rows) {
      if (err) {
        addLog(
          "SELECT ERROR: " +
          err
        );
        callback("error");
        return;
      }

      // EXISTING BLOCK
      if (rows.length) {
        var id =
          rows[0].id;
        pool.query(
          `
          UPDATE dialogue_blocks
          SET
            last_seen_run = ?
          WHERE
            id = ?
          `,
          [
            currentRunId,
            id
          ],
          function(err2) {
            if (err2) {
              addLog(
                "UPDATE ERROR: " +
                err2
              );
              callback(
                "error"
              );
              return;
            }
            pool.query(
              `
              DELETE FROM search_index
              WHERE
                dialogue_id = ?
              `,
              [id],
              function() {
                indexTokens(
                  id,
                  data.text,
                  function() {
                    callback(
                      "duplicate"
                    );
                  }
                );
              }
            );
          }
        );
        return;
      }

      // NEW BLOCK
      pool.query(
        `
        INSERT INTO dialogue_blocks(
          block_hash,
          page,
          title,
          speaker,
          text_content,
          text_normalized,
          url,
          page_order,
          language,
          game,
          last_seen_run
        )
        VALUES(
          ?,?,?,?,?,?,?,?,?,?,?
        )
        `,
        [
          blockHash,
          data.page,
          data.title,
          data.speaker,
          data.text,
          searchNormalize(data.text),
          data.url,
          data.pageOrder,
          data.language,
          data.game,
          currentRunId
        ],

        function(err3,result){
          if (err3) {
            addLog(
              "INSERT ERROR: " +
              err3
            );
            callback(
              "error"
            );
            return;
          }

          indexTokens(
            result.insertId,
            data.text,
            function() {
              callback(
                "inserted"
              );
            }
          );
        }
      );
    }
  );
}

function startIndexing(logger, done) {
  if (logger) {
    addLog = logger;
  }

  currentRunId = Date.now().toString();

  addLog(
    "INDEXER START " +
    currentRunId
  );

  visited = {};

  visited[BASE] = true;
  queue = [BASE];

  processQueue(function() {
    cleanupDeleted(function() {
      addLog(
        "INDEXER COMPLETE"
      );
      if (done) {
        done({
          ok: true
        });
      }
    });
  });
}

function crawlLinksRaw(html) {
  var regex = /href\s*=\s*["']?([^"' >]+\.html)["']?/gi;
  var match;
  var added = 0;

  while ((match = regex.exec(html)) !== null) {
    var href = match[1];
    if (!href)
      continue;

    if (href.indexOf("http") === 0)
      continue;

    if (href.indexOf("#") === 0)
      continue;

    var next = BASE + href.replace(/^\//, "");

    if (!visited[next]) {
      visited[next] = true;
      queue.push(next);
      added++;
    }
  }

  addLog("LINKS ADDED: " + added);
}

function hasLetters(text) {
  return /[A-Za-z\u00C0-\u024F\u0400-\u052F\u2DE0-\u2DFF\uA640-\uA69F\u1800-\u18AF\u3130-\u318F\uAC00-\uD7AF\u3040-\u30FF\u4E00-\u9FFF]/.test(text);
}

function extractTokens(text) {
  if (!text) {
    return [];
  }
  var words =
    searchNormalize(text)
      .split(
        /[^A-Za-z0-9\u0400-\u052F]+/
      )
      .filter(Boolean);

  var tokens = {};
  words.forEach(function(word) {
      // every substring
      // minimum length = 2
      for (var start = 0; start < word.length; start++) {
        for (var end = start + 2; end <= word.length; end++) {
          tokens[word.slice(start, end)] = true;
        }
      }
    }
  );

  return Object.keys(tokens);
}

function indexTokens(dialogueId, text, done) {
  var tokens =  extractTokens(text);

  if (!tokens.length) {
    if (done) {
      done();
    }
    return;
  }

  var values = [];

  tokens.forEach(
    function(token) {
      values.push([
        token,
        dialogueId
      ]);
    }
  );

  pool.query(
    `
      INSERT IGNORE
      INTO search_index
        (
          token,
          dialogue_id
        )
      VALUES ?
    `,
    [values],
    function(err) {
      if (err) {
        addLog(
          "TOKEN INDEX ERROR: " +
          err
        );
      }
      if (done) {
        done();
      }
    }
  );
}

function rebuildSearchIndex(logger, done) {

  if (logger) {
    addLog = logger;
  }

  addLog(
    "SEARCH INDEX REBUILD START"
  );

  pool.query(
    "TRUNCATE TABLE search_index",
    function(err) {

      if (err) {
        addLog(err);
        done && done();
        return;
      }

      pool.query(
        `
        SELECT
          id,
          text_content
        FROM dialogue_blocks
        `,
        function(err, rows) {

          if (err) {
            addLog(err);
            done && done();
            return;
          }

          var batchSize = 1000;
          var i = 0;

          function nextBatch() {

            if (i >= rows.length) {

              addLog(
                "SEARCH INDEX REBUILD DONE"
              );

              done && done();
              return;
            }

            var values = [];

            var end =
              Math.min(
                i + batchSize,
                rows.length
              );

            for (
              ;
              i < end;
              i++
            ) {

              var row = rows[i];

              var tokens =
                extractTokens(
                  row.text_content
                );

              tokens.forEach(
                function(token) {

                  values.push([
                    token,
                    row.id
                  ]);

                }
              );
            }

            pool.query(
              `
              INSERT IGNORE
              INTO search_index
              (
                token,
                dialogue_id
              )
              VALUES ?
              `,
              [values],

              function(err) {

                if (err) {
                  addLog(
                    "BATCH ERROR " +
                    err
                  );
                }

                addLog(
                  "INDEXED " +
                  i +
                  " / " +
                  rows.length
                );

                setImmediate(
                  nextBatch
                );
              }
            );
          }

          nextBatch();
        }
      );
    }
  );
}

function cleanupDeleted(done) {
  addLog(
    "CLEANUP START"
  );

  pool.query(
    `
    SELECT
      id
    FROM dialogue_blocks
    WHERE
      last_seen_run <> ?
      OR
      last_seen_run IS NULL
    `,
    [currentRunId],
    function(err, rows) {
      if (err) {
        addLog(
          "CLEANUP ERROR: " +
          err
        );

        if (done) {
          done();
        }
        return;
      }
      if (!rows.length) {
        addLog(
          "NOTHING TO DELETE"
        );
        if (done) {
          done();
        }
        return;
      }
      var ids =
        rows.map(
          function(r){
            return r.id;
          }
        );

      addLog(
        "DELETE BLOCKS: " +
        ids.length
      );

      pool.query(
        `
        DELETE FROM search_index
        WHERE
          dialogue_id IN (?)
        `,
        [ids],
        function() {
          pool.query(
            `
            DELETE FROM dialogue_blocks
            WHERE
              id IN (?)
            `,
            [ids],
            function() {
              addLog(
                "CLEANUP DONE"
              );
              if (done) {
                done();
              }
            }
          );
        }
      );
    }
  );
}



function searchNormalize(text) {
  if (!text)
    return "";

  return String(text)
    .toLowerCase()
        // h / x family
        .replace(/[һhхx]/g, "х")
        // o family
        .replace(/[oоөѳ]/g, "о")
        // u family
        .replace(/[уyү]/g, "у")
        // elipsis
        .replace(/[…]/g, "...")
        // e family
        .replace(/[ёeе]/g, "e");
}

module.exports = {
  startIndexing: startIndexing,
  rebuildSearchIndex: rebuildSearchIndex
};