﻿process.on("unhandledRejection", function(err) {
    addLog(
      "UNHANDLED REJECTION: " +
      String(err),
      "error"
    );
    console.log(err);
  }
);

process.on("unhandledRejection", function(err) {

  console.log("UNHANDLED REJECTION");
  console.log(err);

});

var http = require('http');
var mysql = require('mysql');
var url = require('url');
var fs = require('fs');
var path = require('path');
var indexer = require('***/backend/indexer.js');
var logs = [];

var LETTERS =
  "A-Za-z0-9" +
  "\\u00C0-\\u024F" +
  "\\u0400-\\u052F" +
  "\\u2DE0-\\u2DFF" +
  "\\uA640-\\uA69F" +
  "\\u1800-\\u18AF" +
  "\\u3130-\\u318F" +
  "\\uAC00-\\uD7AF" +
  "\\u3040-\\u30FF" +
  "\\u4E00-\\u9FFF";

var pool = mysql.createPool({
  connectionLimit: 30,
  host: ***,
  user: ***,
  password: ***,
  database: 'pathologic_search',
  charset: 'utf8mb4'
});

function addLog(text, level) {
  level = level || "info";
  var line ="[" +new Date().toLocaleTimeString() +"] " + text;
  console.log(line);

  pool.query(
    `
      INSERT INTO server_logs
        (level, message)
      VALUES(?,?)
    `,
    [
      level,
      String(text)
    ],
    function(err) {
      if (err) {
        console.log("LOG INSERT ERROR");
        console.log(err);
      }
    }
  );
}

function sendFile(res, filepath, contentType) {
  fs.readFile(filepath, function(err, data) {
    if (err) {
      res.writeHead(404);
      res.end("404");
      return;
    }

    res.writeHead(200, {
      'Content-Type': contentType
    });

    res.end(data);

  });
}

var server = http.createServer(function(req, res) {

// ---------- CORS ----------

res.setHeader(
  "Access-Control-Allow-Origin",
  "https://pathologicdialogue.github.io"
);

res.setHeader(
  "Access-Control-Allow-Methods",
  "GET, POST, OPTIONS"
);

res.setHeader(
  "Access-Control-Allow-Headers",
  "Content-Type"
);

if (
  req.method === "OPTIONS"
) {

  res.writeHead(204);

  res.end();

  return;

}

  var parsed = url.parse(req.url, true);
  parsed.pathname = parsed.pathname.replace(/^\/pathosearch/, "");

  if (parsed.pathname === "") {
    parsed.pathname = "/";
  }

  console.log(parsed.pathname);

 // SEARCH API

if (parsed.pathname == "api/search") {
  res.writeHead(
    200,
    {
      'Content-Type':
        'application/json; charset=UTF-8'
    }
  );

  var q = parsed.query.q;
  var languages = parsed.query.languages;
  var whole = parsed.query.whole;
  var games = parsed.query.games;
  var started = Date.now();

  if (!q || !q.trim()) {
    res.end(
      JSON.stringify([])
    );
    return;
  }

  var normalizedQ = searchNormalize(q);

  var queryTokens = normalizedQ
      .split(/[^A-Za-z0-9\u0400-\u052F]+/)
      .filter(Boolean);

  var useIndex =
    queryTokens.length &&
    queryTokens.every(
      function(token) {
        return token.length >= 2;
      }
    );



  var sql;
  var params;

  // ==========================
  // INDEX SEARCH
  // ==========================
  if (useIndex) {
    var placeholders =
      queryTokens
        .map(function() {
          return "?";
        })
        .join(",");
    sql = `
      SELECT
        d.id,
        d.speaker,
        d.text_content,
        d.url,
        d.language,
        d.game,
        d.page_order
      FROM
        search_index si
      JOIN
        dialogue_blocks d
      ON
        d.id = si.dialogue_id
      WHERE
        si.token IN (
          ` + placeholders + `
        )
    `;

    params = queryTokens.slice();
  }

  // ==========================
  // LIKE FALLBACK
  // ==========================
  else {
    sql = `
      SELECT
        d.id,
        d.speaker,
        d.text_content,
        d.url,
        d.language,
        d.game,
        d.page_order
      FROM
        dialogue_blocks d
      WHERE
        d.text_normalized
        LIKE ?
    `;

    params = [
      "%" +
      normalizedQ +
      "%"
    ];

  }

  // ---------- LANGUAGE FILTER ----------

  if (
    languages &&
    languages.trim()
  ) {

    var list =
      languages
        .split(",")
        .map(function(v) {
          return v.trim();
        })
        .filter(Boolean);

    if (list.length) {

      sql +=
        `
        AND d.language IN (
        ` +
        list
          .map(function() {
            return "?";
          })
          .join(",")
        +
        `)
        `;

      params =
        params.concat(list);

    }

  }

  // ---------- GAME FILTER ----------

  if (
    games &&
    games.trim()
  ) {
    var gameList =
      games
        .split(",")
        .map(function(v) {
          return v.trim();
        })
        .filter(Boolean);
    if (gameList.length) {
      sql +=
        `
        AND d.game IN (
        ` +
        gameList
          .map(function() {
            return "?";
          })
          .join(",")
        +
        `)
        `;
      params = params.concat(gameList);
    }
  }

  // ---------- INDEX GROUPING ----------
  if (useIndex) {
    sql += `
      GROUP BY
        d.id
      HAVING
        COUNT(
          DISTINCT si.token
        ) = ?
    `;

    params.push(
      queryTokens.length
    );

  }

  // ---------- SORTING ----------
  sql += `
    ORDER BY
      d.url ASC,
      d.page_order ASC
  `;
  pool.query(
    sql,
    params,
    function(err, rows) {
      if (err) {
        addLog(
          String(err),
          "error"
        );

        res.end(
          JSON.stringify({
            error: true
          })
        );

        return;
      }

      // ---------- WHOLE WORD ----------
      if (whole === "1") {
        var escaped =
          normalizedQ.replace(
            /[-\/\\^$*+?.()|[\]{}]/g,
            "\\$&"
          );
        var wholeRegex =
          new RegExp(
            "(^|[^" +
            LETTERS +
            "_])" +
            escaped +
            "(?=$|[^" +
            LETTERS +
            "_])",
            "i"
          );
        rows =
          rows.filter(
            function(row) {
              return wholeRegex.test(
                searchNormalize(
                  row.text_content || ""
                )
              );
            }
          );
      }

// ---------- STRICT WILDCARD FILTER ----------

if (
  normalizedQ.indexOf("%") !== -1 ||
  normalizedQ.indexOf("_") !== -1
) {

  var escapedWildcards =
    normalizedQ.replace(
      /[-\/\\^$+?.()|[\]{}]/g,
      "\\$&"
    );

  var strictRegex =
    new RegExp(
      escapedWildcards
        .split("%")
        .join("[\\s\\S]*")
        .split("_")
        .join("[\\s\\S]"),
      "i"
    );

  rows =
    rows.filter(
      function(row) {

        return strictRegex.test(
          searchNormalize(
            row.text_content || ""
          )
        );

      }
    );

}

// ---------- STRICT PHRASE FILTER ----------

if (
  normalizedQ.indexOf("%") === -1 &&
  normalizedQ.indexOf("_") === -1
) {

  rows =
    rows.filter(
      function(row){

        return (
          searchNormalize(
            row.text_content || ""
          )
          .indexOf(
            normalizedQ
          ) !== -1
        );

      }
    );

}

	  // ---------- BUILD MATCHES ----------

rows.forEach(
  function(row){

    row.matchRanges =
      buildMatchRanges(
        row.text_content || "",
        normalizedQ
      );

  }
);

      var duration = Date.now() - started;

      pool.query(
        `
          INSERT INTO search_logs
          (
            query_text,
            normalized_query,
            languages,
            games,
            whole_word,
            result_count,
            duration_ms
          )
          VALUES
          (
            ?,?,?,?,?,?,?
          )
        `,
        [
          q,
          normalizedQ,
          languages || "",
          games || "",
          whole === "1"
            ? 1
            : 0,
          rows.length,
          duration
        ],
        function(err) {
          if (err) {
            addLog(
              "SEARCH LOG ERROR: " +
              String(err),
              "error"
            );
          }
addLog(
  "SEARCH: " +
  JSON.stringify({
    q: q,
    n: normalizedQ,
    l: languages || "",
    g: games || "",
    w: whole || 0,
    r: rows.length,
    ms: duration,
    m:
      useIndex
        ? "I"
        : "L"
  })
);
        }
      );
      res.end(
        JSON.stringify(rows)
      );
    }
  );
}

  // FRONTEND
  else if (parsed.pathname == "pathoadmin" || parsed.pathname == "pathoadmin/") {
    sendFile(
      res,
      "***/frontend/admin.html",
      "text/html"
    );
  }

else if (parsed.pathname == "help" || parsed.pathname == "help/") {
addLog("HELP!");
    sendFile(
      res,
      "***/frontend/help.html",
      "text/html"
    );
  }

  else if (parsed.pathname == "admin.js") {
    sendFile(
      res,
      "***/frontend/admin.js",
      "application/javascript"
    );
  }

  else if (parsed.pathname == "api/reindex") {
    addLog("REINDEX ROUTE ENTERED");
    res.writeHead(200, {
      'Content-Type': 'application/json'
    });
    addLog("START DB CHECK");
    
    pool.query(
      "SELECT COUNT(*) count FROM dialogue_blocks",
      function(err, rows) {
        addLog("DB CALLBACK", err, rows);
        if (err) {
          res.end(JSON.stringify({
            ok: false,
            error: err
          }));
          return;
        }

        var empty = rows[0].count == 0;
        addLog(empty ? "FULL INDEX" : "REINDEX");
        indexer.startIndexing(addLog, function(result) {
          res.end(JSON.stringify(result));
        });
      }
    );
  }

  else if (!parsed.pathname || parsed.pathname == "/") {
    sendFile(
      res,
      "***/frontend/index.html",
      "text/html"
    );
  }

  else if (parsed.pathname == "app.js") {
    sendFile(
      res,
      "***/frontend/app.js",
      "application/javascript"
    );
  }

  else if (parsed.pathname == "style.css") {
    sendFile(
      res,
      "***/frontend/style.css",
      "text/css"
    );
  }

  else if (parsed.pathname == "api/log") {
    res.writeHead(
        200,
        {
            'Content-Type':
                'application/json'
        }
    );

    var offset = parseInt(parsed.query.offset) || 0;
    var limit = parseInt(parsed.query.limit) || 50;
    pool.query(
        `
        SELECT
            id,
            DATE_FORMAT(
                created_at,
                '%Y-%m-%d %H:%i:%s'
            ) AS created_at,
            level,
            message
        FROM server_logs
        ORDER BY
            id DESC
        LIMIT ?
        OFFSET ?
        `,
        [
            limit,
            offset
        ],
        function(err, rows) {
            if (err) {
                addLog(
                    String(err),
                    "error"
                );

                res.end(
                    JSON.stringify([])
                );

                return;
            }

            res.end(
                JSON.stringify(rows)
            );
        }
    );
  }

  else if (parsed.pathname =="api/lognew") {
    res.writeHead(
      200,
      {
        'Content-Type':
          'application/json'
      }
    );

    var after = parseInt(parsed.query.after) || 0;

    pool.query(
      `
        SELECT
          id,
          DATE_FORMAT(
            created_at,
            '%Y-%m-%d %H:%i:%s'
          ) AS created_at,
          level,
          message
        FROM server_logs
        WHERE
          id > ?
        ORDER BY
          id DESC
      `,
      [after],
      function(err, rows) {
        if (err) {
          addLog(
            String(err),
            "error"
          );
          res.end(
            JSON.stringify([])
          );
          return;
        }
        res.end(
          JSON.stringify(rows)
        );
      }
    );
  }

  else if (parsed.pathname == "api/topsearches") {
    res.writeHead(
      200,
      {
        'Content-Type':
          'application/json'
      }
    );
    pool.query(
      `
        SELECT
          (
            SELECT
              s2.query_text
              FROM
               search_logs s2
             WHERE
               s2.normalized_query = s1.normalized_query
               AND
                 s2.languages = s1.languages
               AND
                 s2.games = s1.games
               AND
                 s2.whole_word = s1.whole_word
             GROUP BY
                 s2.query_text
               ORDER BY
                 COUNT(*) DESC,
                 MAX(s2.created_at) DESC
               LIMIT 1
             ) AS query_text,
             s1.normalized_query,
             s1.languages,
             s1.games,
             s1.whole_word,
             COUNT(*) AS count
           FROM
             search_logs s1
           WHERE
               s1.normalized_query IS NOT NULL
             AND
               s1.normalized_query <> ''
           GROUP BY
             s1.normalized_query,
             s1.languages,
             s1.games,
             s1.whole_word
           ORDER BY
             count DESC
           LIMIT 5
       `,
      function(err, rows) {
        if (err) {
          addLog(
            String(err),
            "error"
          );
          res.end(
            JSON.stringify([])
          );
          return;
        }
        res.end(
          JSON.stringify(rows)
        );
      }
    );
  }

else if (parsed.pathname == "api/rebuildindex") {
  addLog("REBUILD INDEX ROUTE");
  res.writeHead(
    200,
    {
      'Content-Type':
        'application/json'
    }
  );

  indexer.rebuildSearchIndex(addLog, 
    function() {
      res.end(
        JSON.stringify({
          ok:true
        })
      );
    }
  );
}

  else {
    res.writeHead(404);
    res.end("404");
  }

});


function buildMatchRanges(
  text,
  query
) {

  if (
    !text ||
    !query
  ) {
    return [];
  }

  var normalizedText =
    searchNormalize(text);

  var normalizedQuery =
    searchNormalize(query);

  var regexText;

  // ---------- literal search ----------

  if (
    normalizedQuery.indexOf("%") === -1 &&
    normalizedQuery.indexOf("_") === -1
  ) {

    regexText =
      normalizedQuery.replace(
        /[-\/\\^$*+?.()|[\]{}]/g,
        "\\$&"
      );

  }

  // ---------- wildcard search ----------

  else {

    regexText =
      normalizedQuery
        .replace(
          /[-\/\\^$*+?.()|[\]{}]/g,
          "\\$&"
        )
        .replace(
          /%/g,
          "[\\s\\S]*?"
        )
        .replace(
          /_/g,
          "[\\s\\S]"
        );

  }

  var regex =
    new RegExp(
      "(?=(" +
      regexText +
      "))",
      "gi"
    );

  var matches = [];

  var m;

  while (
    (m =
      regex.exec(
        normalizedText
      )
    ) !== null
  ) {

    if (!m[1]) {

      regex.lastIndex++;

      continue;

    }

    matches.push([
      m.index,
      m.index +
      m[1].length
    ]);

    // allow overlap

    regex.lastIndex =
      m.index + 1;

  }

  return matches;

}

function searchNormalize(text) {
  if (!text)
    return "";

  return String(text)
    .toLowerCase()
        // h / x family
        .replace(/[һhхx]/g, "х")
        // o family
        .replace(/[oоөѳ]/g, "о")
        // u family
        .replace(/[уyү]/g, "у")
        // elipsis
        .replace(/[…]/g, "...")
        // е family
        .replace(/[ёeе]/g, "e");
}

server.listen(***, ***, function() {
  addLog('Server started);
});