﻿process.on("unhandledRejection", function(err) {
    addLog(
      "UNHANDLED REJECTION: " +
      String(err),
      "error"
    );
    console.log(err);
  }
);

process.on("unhandledRejection", function(err) {

  console.log("UNHANDLED REJECTION");
  console.log(err);

});

var http = require('http');
var mysql = require('mysql');
var url = require('url');
var fs = require('fs');
var path = require('path');
var indexer = require('***/backend/indexer.js');
var logs = [];

var LETTERS =
  "A-Za-z0-9" +
  "\\u00C0-\\u024F" +
  "\\u0400-\\u052F" +
  "\\u2DE0-\\u2DFF" +
  "\\uA640-\\uA69F" +
  "\\u1800-\\u18AF" +
  "\\u3130-\\u318F" +
  "\\uAC00-\\uD7AF" +
  "\\u3040-\\u30FF" +
  "\\u4E00-\\u9FFF";

var pool = mysql.createPool({
  connectionLimit: 30,
  host: ***,
  user: ***,
  password: ***,
  database: 'pathologic_search',
  charset: 'utf8mb4'
});

function addLog(text, level) {
  level = level || "info";
  var line ="[" +new Date().toLocaleTimeString() +"] " + text;
  console.log(line);

  pool.query(
    `
      INSERT INTO server_logs
        (level, message)
      VALUES(?,?)
    `,
    [
      level,
      String(text)
    ],
    function(err) {
      if (err) {
        console.log("LOG INSERT ERROR");
        console.log(err);
      }
    }
  );
}

function sendFile(res, filepath, contentType) {
  fs.readFile(filepath, function(err, data) {
    if (err) {
      res.writeHead(404);
      res.end("404");
      return;
    }

    res.writeHead(200, {
      'Content-Type': contentType
    });

    res.end(data);

  });
}

var server = http.createServer(function(req, res) {

// ---------- CORS ----------

res.setHeader(
  "Access-Control-Allow-Origin",
  "https://pathologicdialogue.github.io"
);

res.setHeader(
  "Access-Control-Allow-Methods",
  "GET, POST, OPTIONS"
);

res.setHeader(
  "Access-Control-Allow-Headers",
  "Content-Type"
);

if (
  req.method === "OPTIONS"
) {

  res.writeHead(204);

  res.end();

  return;

}

  var parsed = url.parse(req.url, true);
  parsed.pathname = parsed.pathname.replace(/^\/pathosearch/, "");

  if (parsed.pathname === "") {
    parsed.pathname = "/";
  }

  console.log(parsed.pathname);

 // SEARCH API

if (parsed.pathname == "api/search") {
  res.writeHead(
    200,
    {
      'Content-Type':
        'application/json; charset=UTF-8'
    }
  );

  var q = parsed.query.q;
  var languages = parsed.query.languages;
  var whole = parsed.query.whole;
  var games = parsed.query.games;
  var normalize = parsed.query.normalize !== "0";
  var ignorePunct = parsed.query.punct === "0";
  var started = Date.now();
  var client = parsed.query.client || "git";

  var searchColumn = "d.text_content";

  if (normalize && ignorePunct) {
    searchColumn = "d.text_normalized_nopunct";
  }
  else if (normalize) {
    searchColumn = "d.text_normalized";
  }
  else if (ignorePunct) {
    searchColumn = "d.text_nopunct";
  }

  if (!q || !q.trim()) {
    res.end(
      JSON.stringify([])
    );
    return;
  }

  var searchQ =
    prepareSearchText(
      q,
      normalize,
      ignorePunct
    );

if (
  !searchQ ||
  !searchQ.trim() ||
  !searchQ.replace(
    /[%_\s]/g,
    ""
  )
) {

  res.end(
    JSON.stringify([])
  );

  return;

}

  var queryTokens =
    searchQ
      .split(
        /[^A-Za-z0-9\u0400-\u052F]+/
      )
      .filter(Boolean);

  var useIndex =
  normalize &&
  searchQ.indexOf("%") === -1 &&
  searchQ.indexOf("_") === -1 &&
    queryTokens.length &&
    queryTokens.every(
      function(token) {
        return token.length >= 2;
      }
    );



  var sql;
  var params;

  // ==========================
  // INDEX SEARCH
  // ==========================
  if (useIndex) {
    var placeholders =
      queryTokens
        .map(function() {
          return "?";
        })
        .join(",");
    sql = `
      SELECT
        d.id,
        d.speaker,
        d.text_content,
        d.url,
        d.language,
        d.game,
        d.page_order
      FROM
        search_index si
      JOIN
        dialogue_blocks d
      ON
        d.id = si.dialogue_id
      WHERE
        si.token IN (
          ` + placeholders + `
        )
    `;

  params =
    queryTokens.slice();

  }

  // ==========================
  // LIKE FALLBACK
  // ==========================
  else {
    sql = `
      SELECT
        d.id,
        d.speaker,
        d.text_content,
        d.url,
        d.language,
        d.game,
        d.page_order
      FROM
        dialogue_blocks d
      WHERE
        ` + searchColumn + `
        LIKE ?
    `;

   var longestToken =
  queryTokens
    .slice()
    .sort(
      function(a,b){
        return b.length - a.length;
      }
    )[0]
  ||
  searchQ;

    params = [
      "%" +
  longestToken +
      "%"
    ];

  }

  // ---------- LANGUAGE FILTER ----------

  if (
    languages &&
    languages.trim()
  ) {

    var list =
      languages
        .split(",")
        .map(function(v) {
          return v.trim();
        })
        .filter(Boolean);

    if (list.length) {

      sql +=
        `
        AND d.language IN (
        ` +
        list
          .map(function() {
            return "?";
          })
          .join(",")
        +
        `)
        `;

      params =
        params.concat(list);

    }

  }

  // ---------- GAME FILTER ----------

  if (
    games &&
    games.trim()
  ) {
    var gameList =
      games
        .split(",")
        .map(function(v) {
          return v.trim();
        })
        .filter(Boolean);
    if (gameList.length) {
      sql +=
        `
        AND d.game IN (
        ` +
        gameList
          .map(function() {
            return "?";
          })
          .join(",")
        +
        `)
        `;
      params = params.concat(gameList);
    }
  }

  // ---------- INDEX GROUPING ----------
  if (useIndex) {
    sql += `
      GROUP BY
        d.id
      HAVING
        COUNT(
          DISTINCT si.token
        ) = ?
    `;

    params.push(
      queryTokens.length
    );

  }

  // ---------- SORTING ----------
  sql += `
    ORDER BY
      d.url ASC,
      d.page_order ASC
  `;
  pool.query(
    sql,
    params,
    function(err, rows) {
      if (err) {
        addLog(
          String(err),
          "error"
        );

        res.end(
          JSON.stringify({
            error: true
          })
        );

        return;
      }

      // ---------- WHOLE WORD ----------
      if (whole === "1") {
        var escaped =
          searchQ.replace(
            /[-\/\\^$*+?.()|[\]{}]/g,
            "\\$&"
          );
        var wholeRegex =
          new RegExp(
            "(^|[^" +
            LETTERS +
            "_])" +
            escaped +
            "(?=$|[^" +
            LETTERS +
            "_])",
            "i"
          );
        rows =
          rows.filter(
            function(row) {
              return wholeRegex.test(
                prepareSearchText(
                  row.text_content || "",
                  normalize,
                  ignorePunct
                )
              );
            }
          );
      }

// ---------- STRICT WILDCARD FILTER ----------

if (
  searchQ.indexOf("%") !== -1 ||
  searchQ.indexOf("_") !== -1
) {

  var escapedWildcards =
    searchQ.replace(
      /[-\/\\^$+?.()|[\]{}]/g,
      "\\$&"
    );

  var strictRegex =
    new RegExp(
      escapedWildcards
        .split("%")
        .join("[\\s\\S]*")
        .split("_")
        .join("[\\s\\S]"),
      "i"
    );

  rows =
    rows.filter(
      function(row) {

        return strictRegex.test(
          prepareSearchText(
            row.text_content || "",
            normalize,
            ignorePunct
          )
        );

      }
    );

}

// ---------- STRICT PHRASE FILTER ----------

if (
  searchQ.indexOf("%") === -1 &&
  searchQ.indexOf("_") === -1
) {

  var phraseRegex =
  buildPhraseRegex(
    searchQ,
    normalize,
    ignorePunct
  );

  rows =
    rows.filter(
      function(row){

        return phraseRegex.test(
          prepareSearchText(
            row.text_content || "",
            normalize,
            ignorePunct
          )
        );
      }
    );

}

	  // ---------- BUILD MATCHES ----------

rows.forEach(
  function(row){

    row.matchRanges =
      buildMatchRanges(
        row.text_content || "",
        searchQ,
        normalize,
        ignorePunct
      );

    if (
      searchQ === "РіСѓ" &&
      row.text_content &&
      row.text_content.indexOf("РіСѓР±Р°С…") !== -1
    ) {

      console.log(
        "MATCH DEBUG:",
        row.matchRanges
      );

  }

  }
);

      var duration = Date.now() - started;

      pool.query(
        `
          INSERT INTO search_logs
          (
            
            query_text,
            normalized_query,
            languages,
            games,
            whole_word,
  normalize_search,
  ignore_punctuation,
            result_count,
            duration_ms

          )
          VALUES
          (
            ?,?,?,?,?,?,?,?,?
          )
        `,
        [
          q,
  searchQ,
          languages || "",
          games || "",
          whole === "1"
            ? 1
            : 0,
  normalize
    ? 1
    : 0,
  ignorePunct
    ? 1
    : 0,
          rows.length,
          duration
        ],
        function(err) {
          if (err) {
            addLog(
              "SEARCH LOG ERROR: " +
              String(err),
              "error"
            );
          }
addLog(
  "SEARCH: " +
  JSON.stringify({
  c: client,
    q: q,
  n: searchQ,
    l: languages || "",
    g: games || "",
    w: whole || 0,
  norm:
    normalize ? 1 : 0,
  punct:
    ignorePunct ? 1 : 0,
    r: rows.length,
    ms: duration,
    m:
      useIndex
        ? "I"
        : "L"
  })
);
        }
      );
      res.end(
        JSON.stringify(rows)
      );
    }
  );
}

  // FRONTEND
  else if (parsed.pathname == "pathoadmin" || parsed.pathname == "pathoadmin/") {
    sendFile(
      res,
      "***/frontend/admin.html",
      "text/html"
    );
  }

else if (parsed.pathname == "help" || parsed.pathname == "help/") {
addLog("HELP!");
    sendFile(
      res,
      "***/frontend/help.html",
      "text/html"
    );
  }

  else if (parsed.pathname == "admin.js") {
    sendFile(
      res,
      "***/frontend/admin.js",
      "application/javascript"
    );
  }

  else if (parsed.pathname == "api/reindex") {
    addLog("REINDEX ROUTE ENTERED");
    res.writeHead(200, {
      'Content-Type': 'application/json'
    });
    addLog("START DB CHECK");
    
    pool.query(
      "SELECT COUNT(*) count FROM dialogue_blocks",
      function(err, rows) {
        addLog("DB CALLBACK", err, rows);
        if (err) {
          res.end(JSON.stringify({
            ok: false,
            error: err
          }));
          return;
        }

        var empty = rows[0].count == 0;
        addLog(empty ? "FULL INDEX" : "REINDEX");
        indexer.startIndexing(addLog, function(result) {
          res.end(JSON.stringify(result));
        });
      }
    );
  }

  else if (!parsed.pathname || parsed.pathname == "/") {
    sendFile(
      res,
      "***/frontend/index.html",
      "text/html"
    );
  }

  else if (parsed.pathname == "app.js") {
    sendFile(
      res,
      "***/frontend/app.js",
      "application/javascript"
    );
  }

  else if (parsed.pathname == "style.css") {
    sendFile(
      res,
      "***/frontend/style.css",
      "text/css"
    );
  }

  else if (parsed.pathname == "api/log") {
    res.writeHead(
        200,
        {
            'Content-Type':
                'application/json'
        }
    );

    var offset = parseInt(parsed.query.offset) || 0;
    var limit = parseInt(parsed.query.limit) || 50;
    pool.query(
        `
        SELECT
            id,
            DATE_FORMAT(
                created_at,
                '%Y-%m-%d %H:%i:%s'
            ) AS created_at,
            level,
            message
        FROM server_logs
        ORDER BY
            id DESC
        LIMIT ?
        OFFSET ?
        `,
        [
            limit,
            offset
        ],
        function(err, rows) {
            if (err) {
                addLog(
                    String(err),
                    "error"
                );

                res.end(
                    JSON.stringify([])
                );

                return;
            }

            res.end(
                JSON.stringify(rows)
            );
        }
    );
  }

  else if (parsed.pathname =="api/lognew") {
    res.writeHead(
      200,
      {
        'Content-Type':
          'application/json'
      }
    );

    var after = parseInt(parsed.query.after) || 0;

    pool.query(
      `
        SELECT
          id,
          DATE_FORMAT(
            created_at,
            '%Y-%m-%d %H:%i:%s'
          ) AS created_at,
          level,
          message
        FROM server_logs
        WHERE
          id > ?
        ORDER BY
          id DESC
      `,
      [after],
      function(err, rows) {
        if (err) {
          addLog(
            String(err),
            "error"
          );
          res.end(
            JSON.stringify([])
          );
          return;
        }
        res.end(
          JSON.stringify(rows)
        );
      }
    );
  }

  else if (parsed.pathname == "api/topsearches") {
    res.writeHead(
      200,
      {
        'Content-Type':
          'application/json'
      }
    );
    pool.query(
      `
        SELECT
          (
            SELECT
              s2.query_text
              FROM
               search_logs s2
             WHERE
               s2.normalized_query = s1.normalized_query
               AND
                 s2.languages = s1.languages
               AND
                 s2.games = s1.games
               AND
                 s2.whole_word = s1.whole_word
AND
  s2.normalize_search =
    s1.normalize_search
AND
  s2.ignore_punctuation =
    s1.ignore_punctuation
             GROUP BY
                 s2.query_text
               ORDER BY
                 COUNT(*) DESC,
                 MAX(s2.created_at) DESC
               LIMIT 1
             ) AS query_text,
             s1.normalized_query,
             s1.languages,
             s1.games,
             s1.whole_word,
s1.normalize_search,
s1.ignore_punctuation,
             COUNT(*) AS count
           FROM
             search_logs s1
           WHERE
               s1.normalized_query IS NOT NULL
             AND
               s1.normalized_query <> ''
           GROUP BY
             s1.normalized_query,
             s1.languages,
             s1.games,
  s1.whole_word,
  s1.normalize_search,
  s1.ignore_punctuation
           ORDER BY
             count DESC
           LIMIT 5
       `,
      function(err, rows) {
        if (err) {
          addLog(
            String(err),
            "error"
          );
          res.end(
            JSON.stringify([])
          );
          return;
        }
        res.end(
          JSON.stringify(rows)
        );
      }
    );
  }

else if (parsed.pathname == "api/rebuildindex") {
  addLog("REBUILD INDEX ROUTE");
  res.writeHead(
    200,
    {
      'Content-Type':
        'application/json'
    }
  );

  indexer.rebuildSearchIndex(addLog, 
    function() {
      res.end(
        JSON.stringify({
          ok:true
        })
      );
    }
  );
}

  else {
    res.writeHead(404);
    res.end("404");
  }

});


function buildMatchRanges(
  text,
  query,
  normalize,
  ignorePunct
) {

  if (
    !text ||
    !query
  ) {
    return [];
  }

  var source =
    String(text);

  // ---------- FAST PATH ----------


  if (
    !normalize &&
    !ignorePunct
  ) {

    var regexText;

  if (
      query.indexOf("%") === -1 &&
      query.indexOf("_") === -1
  ) {

    regexText =
        query.replace(
        /[-\/\\^$*+?.()|[\]{}]/g,
        "\\$&"
      );

  }
  else {

    regexText =
        query
        .replace(
            /[-\/\\^$+?.()|[\]{}]/g,
          "\\$&"
        )
        .replace(
          /%/g,
          "[\\s\\S]*?"
        )
        .replace(
          /_/g,
          "[\\s\\S]"
        );

  }

  var regex =
    new RegExp(
      "(?=(" +
      regexText +
      "))",
      "gi"
    );

  var matches = [];
  var m;

  while (
      (m = regex.exec(source))
      !== null
  ) {

    if (!m[1]) {

      regex.lastIndex++;

      continue;

    }

    matches.push([
      m.index,
      m.index +
      m[1].length
    ]);

      regex.lastIndex =
        m.index + 1;

    }

    return matches;

  }

  // ---------- NORMALIZED PATH ----------

  var prepared = "";
  var map = [];

  for (
    var i = 0;
    i < source.length;
    i++
  ) {

    var transformed =
      source[i];

    if (normalize) {

      transformed =
        searchNormalize(
          transformed
        );

    }

    if (
      ignorePunct &&
      !new RegExp(
        "[" +
        LETTERS +
        "\\s]",
        "u"
      ).test(
        transformed
      )
    ) {

      transformed = " ";

    }

    for (
      var j = 0;
      j < transformed.length;
      j++
    ) {

      prepared +=
        transformed[j];

      map.push(i);

    }

  }

  if (ignorePunct) {

    var compactText = "";
    var compactMap = [];

    var previousSpace =
      false;

    for (
      var k = 0;
      k < prepared.length;
      k++
    ) {

      var c =
        prepared[k];

      if (c === " ") {

        if (
          previousSpace
        ) {
          continue;
        }

        previousSpace =
          true;

      }
      else {

        previousSpace =
          false;

      }

      compactText += c;
      compactMap.push(
        map[k]
      );

    }

    prepared =
      compactText;

    map =
      compactMap;

  }

  var preparedQuery =
    prepareSearchText(
      query,
      normalize,
      ignorePunct
    );

  var regexText;

  if (
    preparedQuery.indexOf("%") === -1 &&
    preparedQuery.indexOf("_") === -1
  ) {

    regexText =
      preparedQuery.replace(
        /[-\/\\^$*+?.()|[\]{}]/g,
        "\\$&"
      );

  }
  else {

    regexText =
      preparedQuery
        .replace(
          /[-\/\\^$+?.()|[\]{}]/g,
          "\\$&"
        )
        .replace(
          /%/g,
          "[\\s\\S]*?"
        )
        .replace(
          /_/g,
          "[\\s\\S]"
        );

  }

  var regex =
    new RegExp(
      "(?=(" +
      regexText +
      "))",
      "gi"
    );

  var matches = [];
  var m;

  while (
    (m = regex.exec(prepared))
    !== null
  ) {

    if (!m[1]) {

      regex.lastIndex++;

      continue;

    }

    var preparedStart =
      m.index;

    var preparedEnd =
      m.index +
      m[1].length -
      1;

    var originalStart =
      map[
        preparedStart
      ];

    var originalEnd =
      map[
        preparedEnd
      ] + 1;

    matches.push([
      originalStart,
      originalEnd
    ]);

    regex.lastIndex =
      m.index + 1;

  }

  return matches;

}

function prepareSearchText(
  text,
  normalize,
  ignorePunct
) {

  var result =
    String(text || "");

  if (normalize) {
    result =
      searchNormalize(result);
  }

  if (ignorePunct) {
    result =
      stripPunctuation(result);
  }

  return result;
}

function stripPunctuation(text) {

  return String(text)
    .replace(
      new RegExp(
        "[^" +
        LETTERS +
        "\\s%_]",
        "gu"
      ),
      " "
    )
    .replace(/\s+/g, " ")
    .trim();

}

function buildPhraseRegex(
  query,
  normalize,
  ignorePunct
) {

  var prepared =
    prepareSearchText(
      query,
      normalize,
      ignorePunct
    );

  var escaped =
    prepared.replace(
      /[-\/\\^$*+?.()|[\]{}]/g,
      "\\$&"
    );

  var separator;

  // ---------- punctuation ignored ----------

  if (ignorePunct) {

    separator =
      "[^" +
      LETTERS +
      "]*";

  }

  // ---------- punctuation significant ----------

  else {

    separator =
      "\\s+";

  }

  return new RegExp(
    escaped.replace(
      /\s+/g,
      separator
    ),
    "i"
  );

}

function searchNormalize(text) {
  if (!text)
    return "";

  return String(text)
    .toLowerCase()
        // h / x family
        .replace(/[һhхx]/g, "х")
        // o family
        .replace(/[oоөѳ]/g, "о")
        // u family
        .replace(/[уyү]/g, "у")
        // elipsis
        .replace(/[…]/g, "...")
        // е family
        .replace(/[ёeе]/g, "e");
}

server.listen(***, ***, function() {
  addLog('Server started);
});